/*
 * hardwareinit.h
 *
 *  Created on: Nov 11, 2017
 *      Author: lenovo
 */

#ifndef HARDWAREINIT_H_
#define HARDWAREINIT_H_
void SystemClock_Config(void);
void MX_GPIO_Init(void);



#endif /* HARDWAREINIT_H_ */
