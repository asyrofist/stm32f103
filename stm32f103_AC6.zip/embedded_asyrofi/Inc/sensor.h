#ifndef SENSOR_H_
#define SENSOR_H_

unsigned char Sensor1(void);
unsigned char Sensor2(void);
unsigned char Sensor3(void);
unsigned char Startstop(void);
unsigned char Reset(void);

#endif /* SENSOR_H_ */
