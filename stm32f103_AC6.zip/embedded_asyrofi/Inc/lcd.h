#ifndef LCD_H_
#define LCD_H_


#define rs_Pin GPIO_PIN_12
#define rs_GPIO_Port GPIOB
#define en_Pin GPIO_PIN_14
#define en_GPIO_Port GPIOB
#define Start_Pin GPIO_PIN_1
#define Start_GPIO_Port GPIOA
#define D4_Pin GPIO_PIN_8
#define D4_GPIO_Port GPIOA
#define D5_Pin GPIO_PIN_9
#define D5_GPIO_Port GPIOA
#define D6_Pin GPIO_PIN_10
#define D6_GPIO_Port GPIOA
#define D7_Pin GPIO_PIN_11
#define D7_GPIO_Port GPIOA
void lcd_init(void);
void lcd_string(const char *xx);
void lcd_gotoxy(unsigned char x, unsigned char y);
void wait_lcd(unsigned long int xx);
void lcd_clear(void);

#endif /* LCD_H_ */
