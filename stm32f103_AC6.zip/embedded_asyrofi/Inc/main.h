 #ifndef __MAIN_H
#define __MAIN_H

unsigned long sec;
#define LD1_Pin GPIO_PIN_13
#define LD1_GPIO_Port GPIOC
#define buzzer_Pin GPIO_PIN_12
#define buzzer_GPIO_Port GPIOA
#define s3_Pin GPIO_PIN_3
#define s3_GPIO_Port GPIOB
#define s2_Pin GPIO_PIN_4
#define s2_GPIO_Port GPIOB
#define s1_Pin GPIO_PIN_5
#define s1_GPIO_Port GPIOB
#define reset_Pin GPIO_PIN_6
#define reset_GPIO_Port GPIOB
#define start_Pin GPIO_PIN_7
#define start_GPIO_Port GPIOB
#define TX_Pin GPIO_PIN_2
#define TX_GPIO_Port GPIOA
#define RX_Pin GPIO_PIN_3
#define RX_GPIO_Port GPIOA

#endif /* __MAIN_H */
