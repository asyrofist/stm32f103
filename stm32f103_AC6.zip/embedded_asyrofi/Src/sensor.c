 #include "stm32f1xx_hal.h"
#include "main.h"
#include "sensor.h"

UART_HandleTypeDef huart2;
#define counterTimeout 30

unsigned char sensor1Detected(void){
	int hasil=0;
	int timeOut;
	if(HAL_GPIO_ReadPin(s1_GPIO_Port,s1_Pin) ){
		HAL_Delay(40);
		if(HAL_GPIO_ReadPin(s1_GPIO_Port,s1_Pin) ){
			timeOut=sec;
			while(HAL_GPIO_ReadPin(s1_GPIO_Port,s1_Pin)&&(sec-timeOut)<counterTimeout);
			if(sec-timeOut<counterTimeout)hasil=1; //kode normal
			else{ hasil=5; //kode error_
			}
		}
	}
	return(hasil);
}

unsigned char sensor2Detected(){
	unsigned char hasil=0;
	int timeOut;
	if(HAL_GPIO_ReadPin(s2_GPIO_Port,s2_Pin)){
		HAL_Delay(40);
		if(HAL_GPIO_ReadPin(s2_GPIO_Port,s2_Pin)){
			timeOut=sec;
			while(HAL_GPIO_ReadPin(s2_GPIO_Port,s2_Pin)&&(sec-timeOut)<counterTimeout);
			if(sec-timeOut<counterTimeout)hasil=1; //kode normal
			else{ hasil=5;
			}
		}
	}
	return(hasil);
}
unsigned char sensor3Detected(){
	unsigned char hasil=0;
	int timeOut;
	if(HAL_GPIO_ReadPin(s3_GPIO_Port,s3_Pin)){
		HAL_Delay(40);
		if(HAL_GPIO_ReadPin(s3_GPIO_Port,s3_Pin)){
			timeOut=sec;
			while(HAL_GPIO_ReadPin(s3_GPIO_Port,s3_Pin)&&(sec-timeOut)<counterTimeout);
			if(sec-timeOut<counterTimeout)hasil=1; //kode normal
			else{ hasil=5; //kode error_
			}
		}
	}
	return(hasil);
}

unsigned char sensorStartStopDetected(){
	unsigned char hasil=0;

	if(!HAL_GPIO_ReadPin(start_GPIO_Port, start_Pin)){
		HAL_Delay(40);
		if(!HAL_GPIO_ReadPin(start_GPIO_Port,start_Pin)){
			while(!HAL_GPIO_ReadPin(start_GPIO_Port,start_Pin)){
				HAL_Delay(1);
			}
			hasil=1;
		}
	}
	return(hasil);
}
unsigned char sensorResetDetected(){
	unsigned char hasil=0;

	if(!HAL_GPIO_ReadPin(reset_GPIO_Port,reset_Pin)){
		HAL_Delay(40);
		if(!HAL_GPIO_ReadPin(reset_GPIO_Port,reset_Pin)){
			while(!HAL_GPIO_ReadPin(reset_GPIO_Port,reset_Pin)){
				HAL_Delay(1);
			}
			hasil=1;
		}
	}
	return(hasil);
}
