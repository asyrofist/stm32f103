#include "stm32f1xx_hal.h"
#include "lcd.h"
#define lcd_wait_const 	1
#define lcd_delay		75000



void wait_lcd(unsigned long int xx)
{
//	xx*= lcd_wait_const;
//    while(xx){xx--;}
		HAL_Delay(1);
}

void lcd_en_clk(void)
{		HAL_GPIO_WritePin(en_GPIO_Port, en_Pin,GPIO_PIN_SET);

wait_lcd(10);					 			// tunggu 2us
HAL_GPIO_WritePin(en_GPIO_Port,en_Pin,GPIO_PIN_RESET );				// reset enable
}

void lcd_ins(unsigned short xx)
{
	HAL_GPIO_WritePin(rs_GPIO_Port,rs_Pin ,GPIO_PIN_RESET );
	HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,(xx&(1<<0))>>0);
	HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,(xx&(1<<1))>>1);
	HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,(xx&(1<<2))>>2);
	HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,(xx&(1<<3))>>3);

	lcd_en_clk();
}
void lcd_ins2(unsigned short xx)
{
	HAL_GPIO_WritePin(rs_GPIO_Port,rs_Pin,GPIO_PIN_SET);
	// set enable
			HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,(xx&(1<<0))>>0);
			HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,(xx&(1<<1))>>1);
			HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,(xx&(1<<2))>>2);
			HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,(xx&(1<<3))>>3);

	lcd_en_clk();
}

void lcd_ins3(unsigned short xx)
{
	HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,(xx&(1<<0))>>0);
	HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,(xx&(1<<1))>>1);
	HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,(xx&(1<<2))>>2);
	HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,(xx&(1<<3))>>3);


}

void lcd_cmd (unsigned char cmd)
{		lcd_ins ((cmd>>4) & 0x0F);	// kirim nibble high
lcd_ins (cmd & 0x0F);		// kirim nibble low
wait_lcd(50);				// tunggu 0.05ms
}

void lcd_data (unsigned char dat)
{		lcd_ins2 ((dat>>4) & 0x0F);	// kirim nibble high
lcd_ins2 (dat & 0x0F);		// kirim nibble low
wait_lcd(50);				// tunggu 0.05ms
}

void lcd_reset(void)
{
	//LCD_PORT |= (0xF<<__LCD_DATA_BIT);
	lcd_ins3(0xf);
	HAL_GPIO_WritePin(rs_GPIO_Port,rs_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(en_GPIO_Port,en_Pin, GPIO_PIN_SET);
	wait_lcd(20000);			// tunggu 20ms
	lcd_ins(3);					// reset #1
	wait_lcd(15000);			// tunggu 15ms
	lcd_ins(3);					// reset #2
	wait_lcd(5000);				// tunggu 5ms
	lcd_ins(3);					// reset #3
	wait_lcd(5000);				// tunggu 5ms
	lcd_ins(2);					// set data transfer 4 bit
	wait_lcd(5000);				// tunggu 5ms
}

void lcd_init(void)
{
	lcd_reset();
lcd_cmd(0x28);				//LCD yang digunakan  = data 4 bit, 2 baris, 5x7 dots
wait_lcd(1000);
lcd_cmd(0x0c);				//Display ON cursor OFF
wait_lcd(1000);
lcd_cmd(0x06);				//Set entry mode - auto increement
wait_lcd(1000);
lcd_cmd(0x01);
wait_lcd(2000);
lcd_cmd(0x80);
wait_lcd(2000);
}

void lcd_gotoxy(unsigned char x, unsigned char y)
{
	lcd_cmd(0x80 | ((y*0x40) + x));
}

void lcd_clear(void)
{	 lcd_cmd(1);}

// menampilkan string ke lCD

void lcd_string(const char *xx)
{	while(*xx) lcd_data(*xx++);
}
// menampilkan data integer ke LCD
void lcd_uint32(unsigned short xx)
{
	lcd_data(xx/10000 + 0x30);
	lcd_data((xx%10000)/1000 + 0x30);
	lcd_data((xx%1000)/100 + 0x30);
	lcd_data((xx%100)/10 + 0x30);
	lcd_data(xx%10 + 0x30);
}

void lcd_uint16(unsigned short xx)
{  //lcd_data(xx/10000 + 0x30);
	lcd_data((xx%10000)/1000 + 0x30);
	lcd_data((xx%1000)/100 + 0x30);
	lcd_data((xx%100)/10 + 0x30);
	lcd_data(xx%10 + 0x30);
}

void lcd_uint2(unsigned short xx)
{
	lcd_data(xx/10 + 0x30);
	lcd_data(xx%10 + 0x30);
}

void lcd_int16 (short int xx)
{  if(xx<0)
{
	lcd_data('-');
	xx=-xx;
}
else lcd_data(' ');
lcd_uint16(xx);
}
