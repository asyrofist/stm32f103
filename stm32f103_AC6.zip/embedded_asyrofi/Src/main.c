#include "main.h"
#include "stm32f1xx_hal.h"
#include "sensor.h"
#include "lcd.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
UART_HandleTypeDef huart2;
#define Error 5
#define Normal 1

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void Error_Handler(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART2_UART_Init(void);
int waktu=0,detik,ms100;
int menit=0,iddle,counterSec;
unsigned char mainFlagTimer,mainLap1,mainLap2,mainLap3;
char 	kata[30];
char 	lcd[30];

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){

	if(htim->Instance== TIM2){
		iddle=1;
		sec++;
		//HAL_GPIO_TogglePin(LD1_GPIO_Port,LD1_Pin);
		if(mainFlagTimer==1){
			ms100++;
			if(ms100>=10){
				detik++;
				if(detik>=60){
					detik=0;
					menit++;
				}
				ms100=0;
			}
		}
	}
}
/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */
int sensor[3];
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  lcd_init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  HAL_TIM_Base_Start_IT(&htim2);
  while (1)
  {
  /* USER CODE END WHILE */

	  HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_13);
	  	  		HAL_Delay(80);
//	  	  		sensor[0]=HAL_GPIO_ReadPin(s1_GPIO_Port,s1_Pin);
//	  	  		sensor[1]=HAL_GPIO_ReadPin(s2_GPIO_Port,s2_Pin);
//	  	  		sensor[2]=HAL_GPIO_ReadPin(s3_GPIO_Port,s3_Pin);


	  	  		if(iddle){

	  	  		sprintf(kata,"%2d:%2d:%2d\r\n",menit,detik,ms100);
	  	  		sprintf(lcd,"%2d:%2d:%2d",menit,detik,ms100);
	  	  			HAL_UART_Transmit(&huart2,kata,10,10);
	  	  			iddle=0;
	  	  			lcd_gotoxy(0,0);
	  	  			lcd_string(lcd);
	  	  		}
	  	  		/*pembacaan sensor 1 */
	  	  		if(sensor1Detected()==Normal){
	  	  			mainLap1++;
	  	  			sprintf(kata,"Mobil 1 -> lap%d = %2d:%2d:%2d\r\n",mainLap1,menit,detik,ms100);
	  	  			HAL_UART_Transmit(&huart2,kata,28,10);

	  	  			if(mainLap1>=4){
	  	  				//sprintf(kata,"1");
	  	  				sprintf(kata,"Mobil 1 -> FINISHED\r\n",mainLap1,menit,detik,ms100);
	  	  				HAL_UART_Transmit(&huart2,kata,21,10);
	  	  			}
	  	  			if(mainLap1>=5)
	  	  			{
	  	  			}
	  	  		}
	  	  		else if(sensor1Detected()==Error){
	  	  			sprintf(kata,"SENSOR 1 error\r\n");
	  	  			HAL_UART_Transmit(&huart2,kata,16,10);
	  	  			lcd_gotoxy(0,1);
	  	  			lcd_string("s 1 error");
	  	  			HAL_Delay(1500);
	  	  		}

	  	  		/*pembacaan sensor 2 */
	  	  		if(sensor2Detected()==Normal){
	  	  			mainLap2++;
	  	  			sprintf(kata,"Mobil 2 -> lap%d = %2d:%2d:%2d\r\n",mainLap2,menit,detik,ms100);
	  	  			HAL_UART_Transmit(&huart2,kata,28,10);

	  	  			if(mainLap2==4){
	  	  				sprintf(kata,"Mobil 2 -> FINISH\r\n",mainLap1,menit,detik,ms100);
	  	  				HAL_UART_Transmit(&huart2,kata,22,10);
	  	  			}
	  	  			if(mainLap2>=5)
	  	  			{
	  	  			}
	  	  		}
	  	  		else if(sensor2Detected()==Error){
	  	  			sprintf(kata,"Sensor 2 error\r\n");
	  	  			HAL_UART_Transmit(&huart2,kata,16,10);
	  	  			lcd_gotoxy(0,1);
	  	  			lcd_string("s 2 error");
	  	  			HAL_Delay(1500);
	  	  		}
	  	  		/*pembacaan sensor 3 */
	  	  		if(sensor3Detected()==Normal){
	  	  			mainLap3++;
	  	  			sprintf(kata,"Mobil 3  lap%1d = %2d:%2d:%2d\r\n",mainLap3,menit,detik,ms100);
	  	  			HAL_UART_Transmit(&huart2,kata,28,10);

	  	  			if(mainLap3>=4){
	  	  				sprintf(kata,"Mobil 3 FINISH\r\n",mainLap1,menit,detik,ms100);
	  	  				HAL_UART_Transmit(&huart2,kata,21,10);
	  	  			}
	  	  			if(mainLap3>=5)
	  	  			{
	  	  			}
	  	  		}
	  	  		else if(sensor3Detected()==Error){
	  	  			sprintf(kata,"Sensor 3 error\r\n");
	  	  			sprintf(lcd,"S 3 error");
	  	  			HAL_UART_Transmit(&huart2,kata,16,10);
	  	  			HAL_Delay(1500);
	  	  			lcd_gotoxy(0,1);
	  	  			lcd_string(lcd);
	  	  		}
	  	  		/*pembacaan start/stop */
	  	  		if(sensorStartStopDetected()){
	  	  			mainFlagTimer^=1;
	  	  		}

	  	  		/*pembacaan reset */
	  	  		if(sensorResetDetected()){
	  	  			menit=0;
	  	  			detik=0;
	  	  			ms100=0;
	  	  		}
	  	  	}

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */


/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7200-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

}

/* USART2 init function */
static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LD1_Pin|rs_Pin|en_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(D7_GPIO_Port, D7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LD1_Pin rs_Pin en_Pin */
  GPIO_InitStruct.Pin = LD1_Pin|rs_Pin|en_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : buzzer_Pin s3_Pin s2_Pin s1_Pin
                           PB7 reset_Pin start_Pin */
  GPIO_InitStruct.Pin = buzzer_Pin|s3_Pin|s2_Pin|s1_Pin
                          |GPIO_PIN_7|reset_Pin|start_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : D7_Pin */
  GPIO_InitStruct.Pin = D4_Pin|D5_Pin|D6_Pin|D7_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler */ 
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
}

#endif
